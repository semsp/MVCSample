using System.Web.Http;
using WebActivatorEx;
using HR.API;
using Swashbuckle.Application;
using System.Linq;

[assembly: PreApplicationStartMethod(typeof(SwaggerConfig), "Register")]

namespace HR.API
{
    public class SwaggerConfig
    {
        public static void Register()
        {
            var thisAssembly = typeof(SwaggerConfig).Assembly;

            GlobalConfiguration.Configuration
                .EnableSwagger(c =>
                    {
                        c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());
                        c.SingleApiVersion("v1", "HR.API");

                    })
                .EnableSwaggerUi(c =>
                    {
                    });
        }
    }
}

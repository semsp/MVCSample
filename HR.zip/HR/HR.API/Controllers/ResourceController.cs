﻿using HR.Domain.Command;
using HR.Domain.Query;
using HR.Domain.ViewModel;
using MediatR;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;

namespace HR.API.Controllers
{
    public class ResourceController : ApiController
    {
        private IMediator _mediator;
        public ResourceController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost]
        [Route("GetResource")]
        public async Task<List<ResourceList>> GetResource([FromBody]GetResourceListQuery query)
        {
            var response = await _mediator.Send(query);
            return response;
        }

        [HttpGet]
        public async Task<ResourceDetail> GetResourceById(string empRefNumber)
        {
            var response = await _mediator.Send(new GetResourceByIdQuery() { EmployeeRefNumber = empRefNumber });
            return response;
        }

        [HttpPost]
        [Route("SaveResource")]
        public async Task<bool> SaveResource(SaveResourceCommand command)
        {
            var response = await _mediator.Send(command);
            return response;
        }

        [HttpDelete]
        public async Task<bool> DeleteResource(DeleteResourceCommand command)
        {
            var response = await _mediator.Send(command);
            return response;
        }


    }
}

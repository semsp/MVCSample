﻿using Autofac;
using Autofac.Integration.WebApi;
using HR.DataAccess;
using HR.DomainLogic;
using MediatR;
using System;
using System.Reflection;
using System.Web.Http;
using System.Web.Mvc;

namespace HR.API
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RegisterAutofac();
        }

        private void RegisterAutofac()
        {
            var builder = new ContainerBuilder();
            var config = GlobalConfiguration.Configuration;

            builder.RegisterApiControllers(Assembly.GetExecutingAssembly());
            builder.RegisterType<HREntities>().InstancePerRequest();

            builder.RegisterType<Mediator>()
                .As<IMediator>()
                .InstancePerLifetimeScope();

            builder.Register<ServiceFactory>(context =>
            {
                var c = context.Resolve<IComponentContext>();
                return t => c.Resolve(t);
            });

            builder.RegisterType<GetResourceListQueryHandler>().AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterType<SaveResourceCommandHandler>().AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterType<GetResourceByIdQueryHandler>().AsImplementedInterfaces().InstancePerDependency();
            builder.RegisterType<DeleteResourceCommandHandler>().AsImplementedInterfaces().InstancePerDependency();

            var container = builder.Build();
            config.DependencyResolver = new AutofacWebApiDependencyResolver(container);
        }
    }
}

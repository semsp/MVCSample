﻿using System;
using System.Linq;
using System.Linq.Expressions;

namespace HR.DataAccess
{
    public static class Extentions
    {
        public static IQueryable<T> OrderByDynamic<T>(this IQueryable<T> query, string attribute, bool isAsc)
        {
            try
            {
                string orderMethodName = isAsc ? "OrderBy" : "OrderByDescending";
                Type t = typeof(T);

                var param = Expression.Parameter(t);
                var property = t.GetProperty(attribute);

                return query.Provider.CreateQuery<T>(
                    Expression.Call(
                        typeof(Queryable),
                        orderMethodName,
                        new Type[] { t, property.PropertyType },
                        query.Expression,
                        Expression.Quote(
                            Expression.Lambda(
                                Expression.Property(param, property),
                                param))
                    ));
            }
            catch (Exception)
            {
                return query; // Return unsorted query
            }
        }
    }
}

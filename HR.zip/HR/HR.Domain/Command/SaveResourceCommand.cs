﻿using MediatR;
using System;
using System.ComponentModel.DataAnnotations;

namespace HR.Domain.Command
{
    public class SaveResourceCommand : IRequest<bool>
    {
        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        public DateTime? DOB { get; set; }

        [Required]
        [RegularExpression(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$", ErrorMessage = "Please enter valid email address.")]
        public string Email { get; set; }

        [Required]
        public string Department { get; set; }

        [Required]
        public string Status { get; set; }

        [Required]
        public string EmployeeRefNumber { get; set; }
    }
}

﻿using MediatR;

namespace HR.Domain.Command
{
    public class DeleteResourceCommand : IRequest<bool>
    {
        public string EmployeeRefNumber { get; set; }
    }
}

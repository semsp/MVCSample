﻿using System;

namespace HR.Domain.ViewModel
{
    public class ResourceList
    {
        public string ResourceName { get; set; }
        public string DOB { get; set; }
        public string Department { get; set; }
        public string Status { get; set; }
        public string EmployeeNumber { get; set; }
    }
}

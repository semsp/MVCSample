﻿using HR.Domain.ViewModel;
using MediatR;

namespace HR.Domain.Query
{
    public class GetResourceByIdQuery : IRequest<ResourceDetail>
    {
        public string EmployeeRefNumber { get; set; }
    }
}

﻿using HR.Domain.ViewModel;
using MediatR;
using System.Collections.Generic;

namespace HR.Domain.Query
{
    public class GetResourceListQuery : IRequest<List<ResourceList>>
    {
        public string Status { get; set; }
        public string Department { get; set; }
        public string SortBy { get; set; }
        public bool IsAscending { get; set; } = true;
        public int PageIndex { get; set; } = 1;
        public int PageSize { get; set; } = 10;
    }
}

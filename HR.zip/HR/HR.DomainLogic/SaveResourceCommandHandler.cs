﻿using HR.DataAccess;
using HR.Domain.Command;
using HR.Domain.Query;
using HR.Domain.ViewModel;
using HR.Infrastructure;
using MediatR;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;


namespace HR.DomainLogic
{
    public class SaveResourceCommandHandler : IRequestHandler<SaveResourceCommand, bool>
    {
        private readonly HREntities _context;
        public SaveResourceCommandHandler(HREntities context)
        {
            _context = context;
        }

        public async Task<bool> Handle(SaveResourceCommand request, CancellationToken cancellationToken)
        {
            Validate(request);

            var resource = await _context.Resources.FirstOrDefaultAsync(p => p.EmployeeNumber == request.EmployeeRefNumber && p.IsDelete == false) ?? new Resource();

            resource.FirstName = request.FirstName;
            resource.LastName = request.LastName;
            resource.EmployeeNumber = request.EmployeeRefNumber;
            resource.Email = request.Email;
            resource.Department = request.Department;
            resource.Status = request.Status;
            resource.DOB = request.DOB;

            if (resource.Id == Guid.Empty)
            {
                resource.CreatedOn = DateTime.UtcNow;
                resource.Id = Guid.NewGuid();
                _context.Resources.Add(resource);
            }
            else
            {
                resource.ModifiedOn = DateTime.UtcNow;
                _context.Entry(resource).State = EntityState.Modified;
            }

            _context.SaveChanges();

            EmailHelper.SendEmail(resource.Email, "hr@mehultestproject.com", "Your Account Detail Updated", "Body Of the email");

            return true;
        }

        public void Validate(SaveResourceCommand request)
        {
            var results = new List<ValidationResult>();
            var context = new ValidationContext(request, null, null);
            Validator.TryValidateObject(request, context, results, true);
            if (results.Count > 0)
                throw new ArgumentException(string.Join(", ", results));
        }
    }
}

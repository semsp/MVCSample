﻿using HR.DataAccess;
using HR.Domain.Command;
using MediatR;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Threading;
using System.Threading.Tasks;


namespace HR.DomainLogic
{
    public class DeleteResourceCommandHandler : IRequestHandler<DeleteResourceCommand, bool>
    {
        private readonly HREntities _context;
        public DeleteResourceCommandHandler(HREntities context)
        {
            _context = context;
        }

        public async Task<bool> Handle(DeleteResourceCommand request, CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(request?.EmployeeRefNumber))
            {
                throw new ArgumentException("EmployeeRefNUmber is required field");
            }

            var resource = await _context.Resources.FirstOrDefaultAsync(p => p.EmployeeNumber == request.EmployeeRefNumber && p.IsDelete == false);

            if (resource == null)
            {
                throw new KeyNotFoundException("Record not found.");
            }

            resource.IsDelete = true;
            resource.ModifiedOn = DateTime.UtcNow;

            _context.Entry(resource).State = EntityState.Modified;
            _context.SaveChanges();

            return true;
        }
    }
}

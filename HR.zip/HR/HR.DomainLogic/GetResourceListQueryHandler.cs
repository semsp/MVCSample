﻿using HR.DataAccess;
using HR.Domain.Query;
using HR.Domain.ViewModel;
using MediatR;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;


namespace HR.DomainLogic
{
    public class GetResourceListQueryHandler : IRequestHandler<GetResourceListQuery, List<ResourceList>>
    {
        private readonly HREntities _context;
        public GetResourceListQueryHandler(HREntities context)
        {
            _context = context;
        }

        public async Task<List<ResourceList>> Handle(GetResourceListQuery request, CancellationToken cancellationToken)
        {
            CheckPagingSortingCriteria(request);

            var resources = _context.Resources.Where(p => (p.Status == request.Status || (request.Status == "" || request.Status == null))
            && (p.Department == request.Department || (request.Department == "" || request.Department == null))
            && p.IsDelete == false)
            .OrderByDynamic(request.SortBy, request.IsAscending)
            .Skip((request.PageIndex - 1) * request.PageSize)
            .Take(request.PageSize)
            .ToList();

            var result = resources.Select(p => new ResourceList()
            {
                ResourceName = p.FirstName + " " + p.LastName,
                DOB = p.DOB.HasValue ? p.DOB.Value.ToString("dd/MM/yyyy") : "",
                Department = p.Department,
                Status = p.Status,
                EmployeeNumber = p.EmployeeNumber
            }).ToList();

            return await Task.FromResult(result);
        }

        private void CheckPagingSortingCriteria(GetResourceListQuery request)
        {
            if (request.PageIndex == 0)
            {
                request.PageIndex = 1;
            }

            if (request.PageSize == 0)
            {
                request.PageSize = 10;
            }

            if (string.IsNullOrWhiteSpace(request.SortBy))
            {
                request.SortBy = "FirstName";
            }
        }
    }
}

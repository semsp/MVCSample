﻿using HR.DataAccess;
using HR.Domain.Query;
using HR.Domain.ViewModel;
using MediatR;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Threading;
using System.Threading.Tasks;

namespace HR.DomainLogic
{
    public class GetResourceByIdQueryHandler : IRequestHandler<GetResourceByIdQuery, ResourceDetail>
    {
        private readonly HREntities _context;
        public GetResourceByIdQueryHandler(HREntities context)
        {
            _context = context;
        }

        public async Task<ResourceDetail> Handle(GetResourceByIdQuery request, CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(request?.EmployeeRefNumber))
            {
                throw new ArgumentException("EmployeeRefNUmber is required field");
            }

            var resource = await _context.Resources.FirstOrDefaultAsync(p => p.EmployeeNumber == request.EmployeeRefNumber && p.IsDelete == false);

            if (resource == null)
            {
                throw new KeyNotFoundException("Record not found.");
            }

            // We can use AutoMapper here to map the entities.
            return new ResourceDetail()
            {
                FirstName = resource.FirstName,
                LastName = resource.LastName,
                Department = resource.Department,
                DOB = resource.DOB.HasValue ? resource.DOB.Value.ToString("dd/MM/yyyy") : "",
                Email = resource.Email,
                EmployeeNumber = resource.EmployeeNumber,
                Status = resource.Status
            };
        }
    }
}
